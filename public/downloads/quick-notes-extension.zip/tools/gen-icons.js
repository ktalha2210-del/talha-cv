/*
 * Quick Notes — icon generator (no dependencies).
 *
 * Draws a rounded-square badge with an "N" and writes PNGs to ../icons.
 * Run once:  node tools/gen-icons.js
 * The generated PNGs are committed, so Node is NOT needed to use the extension.
 */

"use strict";

var fs = require("fs");
var path = require("path");
var zlib = require("zlib");

var OUT_DIR = path.join(__dirname, "..", "icons");
var SIZES = [16, 32, 48, 128];

var BG = [59, 111, 224]; // #3b6fe0 — visible on light & dark toolbars
var FG = [255, 255, 255];

/* ---------------------------------------------------------- drawing ---- */

function clamp01(n) {
  return n < 0 ? 0 : n > 1 ? 1 : n;
}

// Signed helper: is (u,v) within a rounded rectangle [0,1]^2 with corner r?
function inRoundedRect(u, v, r) {
  var x = Math.min(u, 1 - u);
  var y = Math.min(v, 1 - v);
  if (x > r && y > r) return true;
  if (x > r || y > r) return x >= 0 && y >= 0;
  var dx = r - x;
  var dy = r - y;
  return dx * dx + dy * dy <= r * r;
}

// Distance from point to segment P0->P1 in unit space.
function distToSegment(u, v, x0, y0, x1, y1) {
  var dx = x1 - x0;
  var dy = y1 - y0;
  var len2 = dx * dx + dy * dy;
  var t = len2 ? clamp01(((u - x0) * dx + (v - y0) * dy) / len2) : 0;
  var cx = x0 + t * dx;
  var cy = y0 + t * dy;
  return Math.hypot(u - cx, v - cy);
}

// Is unit point (u,v) inside the "N" glyph?
function isMark(u, v) {
  var stemW = 0.17;
  var top = 0.20;
  var bot = 0.80;
  if (u >= 0.21 && u <= 0.21 + stemW && v >= top && v <= bot) return true; // left stem
  if (u >= 0.62 && u <= 0.62 + stemW && v >= top && v <= bot) return true; // right stem
  if (distToSegment(u, v, 0.295, top, 0.705, bot) <= 0.11) return true; // diagonal
  return false;
}

// Average an fn(u,v)->bool over an NxN grid of sub-samples inside pixel (x,y).
function coverage(fn, x, y, size, samples) {
  var hits = 0;
  for (var sy = 0; sy < samples; sy++) {
    for (var sx = 0; sx < samples; sx++) {
      var u = (x + (sx + 0.5) / samples) / size;
      var v = (y + (sy + 0.5) / samples) / size;
      if (fn(u, v)) hits++;
    }
  }
  return hits / (samples * samples);
}

function renderRGBA(size) {
  var buf = Buffer.alloc(size * size * 4);
  var radius = 0.18;
  var ss = size <= 32 ? 4 : 3;

  var inBadge = function (u, v) {
    return inRoundedRect(u, v, radius);
  };

  for (var y = 0; y < size; y++) {
    for (var x = 0; x < size; x++) {
      var i = (y * size + x) * 4;

      var bgIn = coverage(inBadge, x, y, size, ss);
      var markIn =
        bgIn > 0
          ? coverage(function (u, v) {
              return inBadge(u, v) && isMark(u, v);
            }, x, y, size, ss)
          : 0;

      var r = BG[0];
      var g = BG[1];
      var bl = BG[2];
      if (bgIn > 0 && markIn > 0) {
        var f = Math.min(1, markIn / bgIn); // mark share of the covered area
        r = Math.round(BG[0] * (1 - f) + FG[0] * f);
        g = Math.round(BG[1] * (1 - f) + FG[1] * f);
        bl = Math.round(BG[2] * (1 - f) + FG[2] * f);
      }
      buf[i] = r;
      buf[i + 1] = g;
      buf[i + 2] = bl;
      buf[i + 3] = Math.round(bgIn * 255);
    }
  }
  return buf;
}

/* ------------------------------------------------------------ PNG ----- */

var CRC_TABLE = (function () {
  var t = new Uint32Array(256);
  for (var n = 0; n < 256; n++) {
    var c = n;
    for (var k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(buf) {
  var c = 0xffffffff;
  for (var i = 0; i < buf.length; i++) {
    c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  var len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  var typeBuf = Buffer.from(type, "ascii");
  var body = Buffer.concat([typeBuf, data]);
  var crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body), 0);
  return Buffer.concat([len, body, crc]);
}

function encodePNG(rgba, size) {
  var sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  var ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // color type RGBA
  ihdr[10] = 0; // compression
  ihdr[11] = 0; // filter
  ihdr[12] = 0; // interlace

  var stride = size * 4;
  var raw = Buffer.alloc((stride + 1) * size);
  for (var y = 0; y < size; y++) {
    raw[y * (stride + 1)] = 0; // filter type 0 (None)
    rgba.copy(raw, y * (stride + 1) + 1, y * stride, y * stride + stride);
  }
  var idat = zlib.deflateSync(raw, { level: 9 });

  return Buffer.concat([
    sig,
    chunk("IHDR", ihdr),
    chunk("IDAT", idat),
    chunk("IEND", Buffer.alloc(0))
  ]);
}

/* ----------------------------------------------------------- main ---- */

function main() {
  if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });
  SIZES.forEach(function (size) {
    var rgba = renderRGBA(size);
    var png = encodePNG(rgba, size);
    var file = path.join(OUT_DIR, "icon-" + size + ".png");
    fs.writeFileSync(file, png);
    console.log("wrote " + path.relative(process.cwd(), file) + " (" + png.length + " bytes)");
  });

  // A simple master SVG for future edits.
  var svg =
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">' +
    '<rect x="2" y="2" width="96" height="96" rx="18" fill="#3b6fe0"/>' +
    '<path d="M30 22h15v56H30zM55 22h15v56H55zM33 22 L67 78 h-15 L18 22z" fill="#fff" opacity="0"/>' +
    '<path d="M29 22h13v56H29zM58 22h13v56H58z" fill="#fff"/>' +
    '<path d="M31 20 L69 80" stroke="#fff" stroke-width="15" stroke-linecap="round"/>' +
    "</svg>\n";
  fs.writeFileSync(path.join(OUT_DIR, "icon.svg"), svg);
  console.log("wrote " + path.relative(process.cwd(), path.join(OUT_DIR, "icon.svg")));
}

main();
