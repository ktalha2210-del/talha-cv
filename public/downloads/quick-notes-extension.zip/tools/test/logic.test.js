/* Headless smoke test for the framework-free logic modules. */
"use strict";
const fs = require("fs");
const path = require("path");

const ROOT = path.join(__dirname, "..", "..", "src");
let passed = 0,
  failed = 0;
function ok(name, cond) {
  if (cond) {
    passed++;
    console.log("  ok  " + name);
  } else {
    failed++;
    console.error("  FAIL " + name);
  }
}
function eqish(a, b) {
  return JSON.stringify(a) === JSON.stringify(b);
}

/* ---- environment stubs ------------------------------------------- */
Object.defineProperty(global, "navigator", {
  value: { userAgent: "Macintosh; Intel Mac OS X 10_15", platform: "MacIntel" },
  configurable: true
});
if (!global.performance) global.performance = { now: () => Date.now() };

function makeChrome() {
  const store = {};
  const listeners = [];
  return {
    _store: store,
    runtime: { getURL: (p) => p, lastError: null },
    storage: {
      local: {
        get: (key) =>
          Promise.resolve(
            key == null ? { ...store } : { [key]: store[key] }
          ),
        set: (obj) => {
          const changes = {};
          for (const k in obj) {
            changes[k] = { oldValue: store[k], newValue: obj[k] };
            store[k] = obj[k];
          }
          listeners.forEach((l) => l(changes, "local"));
          return Promise.resolve();
        }
      },
      onChanged: {
        addListener: (fn) => listeners.push(fn),
        removeListener: (fn) => {
          const i = listeners.indexOf(fn);
          if (i >= 0) listeners.splice(i, 1);
        }
      }
    }
  };
}

function load(rel) {
  const code = fs.readFileSync(path.join(ROOT, rel), "utf8");
  (0, eval)(code); // indirect eval → runs IIFE, which writes globalThis.QN
}

/* ---- fresh module set ------------------------------------------- */
function reset() {
  delete global.QN;
  global.chrome = makeChrome();
  load("shared/constants.js");
  load("shared/date-utils.js");
  load("shared/storage.js");
}

/* =============================================================== */
(async function main() {
  console.log("date-utils");
  reset();
  const QN = global.QN;
  const now = new Date(2026, 8, 11, 15, 0, 0).getTime(); // Sep 11 2026 3pm
  ok(
    "today",
    /^Today · \d/.test(QN.formatTimestamp(new Date(2026, 8, 11, 9, 12).getTime(), now))
  );
  ok(
    "yesterday",
    /^Yesterday · /.test(QN.formatTimestamp(new Date(2026, 8, 10, 18, 30).getTime(), now))
  );
  ok(
    "same-year no year shown",
    (function () {
      const s = QN.formatTimestamp(new Date(2026, 8, 3, 16, 15).getTime(), now);
      return /Sep 3 · /.test(s) && !/2026/.test(s);
    })()
  );
  ok(
    "older year shows year",
    /Sep 3, 2024 · /.test(
      QN.formatTimestamp(new Date(2024, 8, 3, 16, 15).getTime(), now)
    )
  );

  console.log("storage: settings");
  reset();
  let s = await global.QN.storage.getSettings();
  ok("mac default modifier = Control", s.primaryModifier === "Control");
  ok("default peek key", s.peekKey === "q");
  ok("default double-tap window", s.doubleTapWindow === 400);
  s = await global.QN.storage.saveSettings({ primaryModifier: "Alt", doubleTapWindow: 99999 });
  ok("saved modifier persists", s.primaryModifier === "Alt");
  ok("window clamped", s.doubleTapWindow === 1500);
  s = await global.QN.storage.resetSettings();
  ok("reset restores Control", s.primaryModifier === "Control");

  console.log("storage: notes CRUD + sort");
  reset();
  const st = global.QN.storage;
  const a = await st.createNote({ content: "alpha", createdAt: 1000, updatedAt: 1000 });
  const b = await st.createNote({ content: "bravo", createdAt: 2000, updatedAt: 2000 });
  ok("two notes", (await st.getNotes()).length === 2);
  ok("sorted updatedAt DESC", (await st.getNotes())[0].id === b.id);
  await st.updateNote(a.id, "alpha!");
  const notes = await st.getNotes();
  ok("update bumps to front", notes[0].id === a.id);
  ok("content updated", notes[0].content === "alpha!");
  ok("updatedAt advanced", notes[0].updatedAt > notes[0].createdAt);
  ok("createdAt preserved", notes[0].createdAt === 1000);
  const del = await st.deleteNote(b.id);
  ok("delete returns true", del === true);
  ok("one note left", (await st.getNotes()).length === 1);
  ok("double-create same id is idempotent", (await st.createNote({ id: a.id, content: "x" })) && (await st.getNotes()).length === 1);

  console.log("storage: onChange fires");
  reset();
  let got = null;
  global.QN.storage.onChange((p) => (got = p));
  await global.QN.storage.createNote({ content: "hi" });
  await new Promise((r) => setTimeout(r, 5));
  ok("onChange delivered notes array", got && Array.isArray(got.notes) && got.notes.length === 1);

  console.log("state machine");
  reset();
  // minimal stubs the content modules expect
  global.requestAnimationFrame = (fn) => setTimeout(fn, 0);
  let renders = 0;
  const statusCalls = [];
  const toastCalls = [];
  global.QN.panel = {
    render: () => renders++,
    isMounted: () => true,
    setStatus: (t) => statusCalls.push(t),
    toast: (t) => toastCalls.push(t)
  };
  load("content/state.js");
  const A = global.QN.actions;
  const S = global.QN.state;
  A.setSettings(await global.QN.storage.getSettings());

  ok("starts CLOSED", S.mode === "closed");
  A.openTemporary();
  ok("hold → temporary", S.mode === "temporary");
  A.close();
  ok("release → closed", S.mode === "closed");
  A.openTemporary();
  A.openSticky();
  ok("double-tap path → sticky", S.mode === "sticky");
  A.newNote();
  ok("Mod+N → editor", S.mode === "editor");
  ok("returnTo sticky (came from sticky)", S.editorReturnTo === "sticky");
  global.QN.handleInput("hello world");
  await new Promise((r) => setTimeout(r, 350)); // debounce flush
  let n = await global.QN.storage.getNotes();
  ok("typed note persisted", n.length === 1 && n[0].content === "hello world");
  A.backFromEditor();
  ok("back → sticky", S.mode === "sticky");

  // empty draft discarded
  A.newNote();
  ok("new editor", S.mode === "editor");
  A.backFromEditor();
  n = await global.QN.storage.getNotes();
  ok("untouched draft NOT persisted", n.length === 1);

  // edit + delete
  A.editNote(n[0].id, "sticky");
  ok("editing existing", S.mode === "editor" && S.draftPersisted === true);
  A.deleteActive();
  await new Promise((r) => setTimeout(r, 5));
  n = await global.QN.storage.getNotes();
  ok("deleteActive removed note", n.length === 0);
  ok("after delete → sticky", S.mode === "sticky");

  // delete straight from the list row
  await global.QN.storage.createNote({ content: "row-delete-me" });
  await new Promise((r) => setTimeout(r, 5));
  A.setNotes(await global.QN.storage.getNotes());
  const rowId = S.notes.find((x) => x.content === "row-delete-me").id;
  A.openSticky();
  A.deleteNoteById(rowId);
  await new Promise((r) => setTimeout(r, 5));
  ok("deleteNoteById removes from cache", !S.notes.some((x) => x.id === rowId));
  ok("deleteNoteById removes from storage", !(await global.QN.storage.getNotes()).some((x) => x.id === rowId));

  // sticky close
  A.close();
  ok("close → closed", S.mode === "closed");

  console.log("editor: Enter-to-save + status");
  statusCalls.length = 0;
  toastCalls.length = 0;
  A.openSticky();
  A.newNote();
  global.QN.handleInput("note via enter");
  ok("typing reports 'saving'", statusCalls.includes("saving"));
  await new Promise((r) => setTimeout(r, 350));
  ok("debounced save reports 'saved'", statusCalls.includes("saved"));
  A.saveAndExitEditor();
  ok("Enter exits editor", S.mode !== "editor");
  ok("Enter shows a Saved toast", toastCalls[toastCalls.length - 1] === "Saved");
  n = await global.QN.storage.getNotes();
  ok("note persisted via enter flow", n.some((x) => x.content === "note via enter"));

  // Enter on an untouched new note: no toast, nothing saved
  toastCalls.length = 0;
  const countBefore = (await global.QN.storage.getNotes()).length;
  A.openSticky();
  A.newNote();
  A.saveAndExitEditor();
  ok("empty note → no toast", toastCalls.length === 0);
  ok("empty note → not persisted", (await global.QN.storage.getNotes()).length === countBefore);

  console.log("");
  console.log(passed + " passed, " + failed + " failed");
  process.exit(failed ? 1 : 0);
})();
