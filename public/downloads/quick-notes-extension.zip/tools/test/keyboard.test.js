/* Keyboard state-machine simulation (the highest-risk area). */
"use strict";
const fs = require("fs");
const path = require("path");
const ROOT = path.join(__dirname, "..", "..", "src");
let passed = 0, failed = 0;
const ok = (n, c) => (c ? (passed++, console.log("  ok  " + n)) : (failed++, console.error("  FAIL " + n)));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

Object.defineProperty(global, "navigator", {
  value: { userAgent: "Macintosh; Intel Mac OS X", platform: "MacIntel" },
  configurable: true
});
global.requestAnimationFrame = (fn) => setTimeout(fn, 0);

const H = {};
const addL = (t, fn) => (H[t] = H[t] || []).push(fn);
global.window = { addEventListener: addL, removeEventListener() {} };
global.document = { addEventListener: addL, removeEventListener() {}, hidden: false };
const fire = (t, ev) => (H[t] || []).forEach((fn) => fn(ev));

const base = () => ({
  preventDefault() {}, stopImmediatePropagation() {}, stopPropagation() {},
  repeat: false, ctrlKey: false, altKey: false, metaKey: false, shiftKey: false
});
const kd = (o) => Object.assign(base(), o);
const ku = kd;

function makeChrome() {
  const store = {}, ls = [];
  return {
    runtime: { getURL: (p) => p },
    storage: {
      local: {
        get: (k) => Promise.resolve(k == null ? { ...store } : { [k]: store[k] }),
        set: (o) => { const c = {}; for (const k in o) { c[k] = { newValue: o[k] }; store[k] = o[k]; } ls.forEach((l) => l(c, "local")); return Promise.resolve(); }
      },
      onChanged: { addListener: (f) => ls.push(f), removeListener() {} }
    }
  };
}
const load = (rel) => (0, eval)(fs.readFileSync(path.join(ROOT, rel), "utf8"));

const CTRL = { key: "Control", ctrlKey: true };
const Q = { key: "q", code: "KeyQ", ctrlKey: true };
const N = { key: "n", code: "KeyN", ctrlKey: true };

(async function () {
  delete global.QN;
  global.chrome = makeChrome();
  for (const k in H) delete H[k];
  load("shared/constants.js");
  load("shared/date-utils.js");
  load("shared/storage.js");
  load("content/state.js");
  global.QN.panel = { render() {}, isMounted: () => true };
  load("content/keyboard.js");
  const QN = global.QN, S = QN.state;
  QN.actions.setSettings(await QN.storage.getSettings()); // mac → Control
  QN.keyboard.attach();
  const W = S.settings.doubleTapWindow; // 400

  // 1. single hold peek
  fire("keydown", kd(CTRL));
  fire("keydown", kd(Q));
  ok("hold Ctrl+Q → temporary", S.mode === "temporary");
  fire("keydown", kd(Object.assign({}, Q, { repeat: true })));
  ok("auto-repeat ignored", S.mode === "temporary");
  fire("keyup", ku(Q));
  ok("release Q → closed", S.mode === "closed");

  // 2. wait out the window, then a fresh single peek is temporary again
  await sleep(W + 60);
  fire("keydown", kd(Q));
  ok("fresh single press → temporary (not sticky)", S.mode === "temporary");
  fire("keyup", ku(Q));
  ok("release → closed", S.mode === "closed");

  // 3. double tap within the window → sticky
  await sleep(W + 60); // clean slate
  fire("keydown", kd(Q)); // press 1 → temporary
  fire("keyup", ku(Q)); // → closed
  await sleep(120); // < window
  fire("keydown", kd(Q)); // press 2 → double
  ok("double Ctrl+Q → sticky", S.mode === "sticky");
  fire("keyup", ku(Q));
  ok("sticky survives key release", S.mode === "sticky");

  // 4. peek key while sticky closes it
  fire("keydown", kd(Q));
  ok("Ctrl+Q while sticky → closed", S.mode === "closed");
  fire("keyup", ku(Q));

  // 5. Ctrl released before Q
  await sleep(W + 60);
  fire("keydown", kd(CTRL));
  fire("keydown", kd(Q));
  ok("temporary open", S.mode === "temporary");
  fire("keyup", ku(CTRL));
  ok("Ctrl up before Q → closed", S.mode === "closed");
  fire("keyup", ku(Q));

  // 6. blur while holding peek
  await sleep(W + 60);
  fire("keydown", kd(CTRL));
  fire("keydown", kd(Q));
  ok("temporary open", S.mode === "temporary");
  fire("blur", {});
  ok("blur → closed + keys reset", S.mode === "closed" && !S.keys.peekDown && !S.keys.modifierDown);

  // 7. tab hidden while holding peek
  await sleep(W + 60);
  fire("keydown", kd(CTRL));
  fire("keydown", kd(Q));
  global.document.hidden = true;
  fire("visibilitychange", {});
  ok("tab hidden → closed", S.mode === "closed");
  global.document.hidden = false;

  // 8. Mod+N → editor ; Escape → leaves editor
  fire("keydown", kd(N));
  ok("Ctrl+N → editor", S.mode === "editor");
  fire("keydown", kd({ key: "Escape" }));
  ok("Escape → not editor", S.mode !== "editor");

  // 9. plain typing unaffected
  const before = S.mode;
  fire("keydown", kd({ key: "n", code: "KeyN" }));
  fire("keydown", kd({ key: "q", code: "KeyQ" }));
  ok("plain n / q ignored", S.mode === before);

  // 10. master switch off
  QN.actions.setSettings(Object.assign({}, S.settings, { shortcutsEnabled: false }));
  await sleep(W + 60);
  fire("keydown", kd(CTRL));
  fire("keydown", kd(Q));
  ok("shortcuts disabled → nothing opens", S.mode === "closed");

  // 11. Alt modifier on a simulated Windows profile
  QN.actions.setSettings(Object.assign({}, S.settings, { shortcutsEnabled: true, primaryModifier: "Alt" }));
  await sleep(W + 60);
  fire("keydown", kd({ key: "Alt", altKey: true }));
  fire("keydown", kd({ key: "q", code: "KeyQ", altKey: true }));
  ok("Alt+Q → temporary", S.mode === "temporary");
  fire("keyup", ku({ key: "q", code: "KeyQ", altKey: true }));
  ok("release → closed", S.mode === "closed");
  // Ctrl+Q must NOT trigger when modifier is Alt
  fire("keydown", kd(CTRL));
  fire("keydown", kd(Q));
  ok("Ctrl+Q ignored when modifier=Alt", S.mode === "closed");

  console.log("");
  console.log(passed + " passed, " + failed + " failed");
  process.exit(failed ? 1 : 0);
})();
