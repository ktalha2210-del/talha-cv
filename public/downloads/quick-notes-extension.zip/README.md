# Quick Notes

A tiny, keyboard-first scratchpad that lives on top of whatever page you're on.
Create a note without leaving the page, glance at old notes with a held hotkey,
or pin the panel with a double-tap. Everything is stored locally in
`chrome.storage.local` — no account, no sync, no network, no analytics.

```
Mod + N            → new note, cursor already blinking — just type
Hold Mod + Q       → peek at your notes (read-only); release to dismiss
Mod + Q, Mod + Q   → pin the panel open (sticky)
```

`Mod` is **Ctrl** on macOS and **Alt** on Windows/Linux by default (see
[Browser limitations](#browser-limitations)). Every key is rebindable from the
toolbar popup.

> New here? Read the **[User Guide](USER_GUIDE.md)** for a plain walkthrough of
> the day-to-day usage.

---

## Install (no build step)

There is nothing to compile. The `src/` folder is the extension.

1. Download / clone this folder.
2. Open **`chrome://extensions`**.
3. Turn on **Developer mode** (top-right).
4. Click **Load unpacked** and select the `quick-notes-extension/` folder (the
   one containing `manifest.json`).
5. The **N** icon appears in the toolbar. Pin it if you like.

### Reloading after changes

- **Content scripts / styles / popup** — click the ↻ reload icon on the
  extension's card in `chrome://extensions`, then **refresh any open tabs** so
  the new content script is injected.
- **`manifest.json` / `service-worker.js`** — same ↻ reload icon; the service
  worker restarts automatically.

### Running the logic tests (optional)

Headless Node checks for the storage layer, date formatting, the mode state
machine, and every keyboard edge case (hold, release order, double-tap timing,
blur/tab-switch cleanup, `Alt` vs `Ctrl` modifier):

```bash
npm test        # node tools/test/*.test.js — no dependencies
```

### Regenerating the icons (optional)

The PNG icons are committed, so Node is **not** required to use the extension.
If you want to change the icon, edit `tools/gen-icons.js` and run:

```bash
node tools/gen-icons.js      # or: npm run icons
```

---

## Usage

### New note — `Mod + N`

Opens the panel straight into the editor with the cursor active. Start typing
immediately; there is no "+ New note" click and no Save button. If you type
nothing and close the editor, the empty note is discarded.

### Peek — hold `Mod + Q`

Shows a **read-only** list of your notes (newest first) for as long as you hold
the shortcut. Releasing either key dismisses it. No clicking, no focus stolen
from the page — it's a glance.

### Sticky — `Mod + Q` twice

Press `Mod + Q` twice within the double-tap window (default **400 ms**) to pin
the panel. It stays open after you release the keys. In sticky mode you can:

- scroll the list,
- click a note to **edit** it,
- click **+** to create a note,
- click **×** to close (this also exits sticky mode).

Pressing `Mod + Q` once more while the panel is sticky **closes it**. This
resolves the double-trigger ambiguity in favour of predictable behaviour; you
can turn it off in **Settings → "Peek key closes sticky panel"**.

The panel opens **centred on the screen**. While you're editing, the page behind
it is gently dimmed; peek and sticky views leave the page fully usable.

### Writing, saving & deleting

- **In the editor:** press **Enter** to save and close, **Shift + Enter** for a
  new line.
- **Save feedback:** the footer shows `Saving…` then `✓ Saved` as you type, and a
  `Saved` pill pops up when you commit with Enter.
- **Autosave** also runs on its own — ~300 ms after you stop typing, and
  immediately when the editor loses focus or closes — so nothing is ever lost.
- **Edit:** click a note in the sticky panel, or open any note from the toolbar
  popup.
- **Delete:** hover a note row and click the 🗑 icon (in the sticky panel or the
  popup), or use **Delete** inside the editor. Either way it asks first
  (`Delete this note?` → `Cancel` / `Delete`). Escape never deletes anything.
- **`Escape`** in the editor returns to the list (sticky) or closes the panel
  (opened via `Mod + N`); a brand-new note with no text is discarded.

### Toolbar popup

Clicking the **N** icon opens a full manager: browse every note, edit, delete,
create, and a **Settings** pane (gear icon) for shortcuts and behaviour. Use the
popup on pages where the on-page panel can't run (see below).

---

## State model

```
        Mod+Q (hold)                 release Mod or Q
CLOSED ──────────────▶ TEMPORARY ──────────────────────▶ CLOSED
   │                   (read-only)
   │  Mod+Q ×2                                   × button / Mod+Q
   ├──────────────────▶ STICKY ─────────────────────────▶ CLOSED
   │                   (interactive list)
   │  Mod+N                                    Esc / back / ×
   └──────────────────▶ EDITOR ─────────────────────────▶ CLOSED or STICKY
```

Exactly one `mode` is active at a time (`src/content/state.js`) — there are no
loose booleans that could form an impossible combination. Keyboard state
(`modifier down`, `peek key down`, `last peek time`) is reset on window blur and
tab switch so a held peek can never leave a stuck panel behind.

---

## Settings

Open the popup → gear icon.

| Setting | Default | Notes |
|---|---|---|
| Modifier key | `Ctrl` (macOS) / `Alt` (Win/Linux) | `Ctrl`, `Alt`, or `Cmd`/`Win` |
| New note key | `n` | single character |
| Peek key | `q` | single character |
| Double-tap window | `400` ms | 150–1500 ms |
| Peek key closes sticky panel | on | off = only the `×` button closes sticky |
| On-page shortcuts | on | master switch; off = popup-only |

There is also an **optional browser-level command**. Visit
`chrome://extensions/shortcuts`, find **Quick Notes → "Create a new note"**, and
assign a key. Chrome delivers that one even on pages where content scripts are
blocked, and the service worker forwards it to the active tab.

---

## Browser limitations

- **`Ctrl + N` / `Ctrl + Q` cannot be intercepted on Windows/Linux.** The
  browser/OS consume them (new window / quit) before any page script sees them.
  That's why the default modifier is **Alt** there. On macOS the browser uses
  **Cmd** for those, so `Ctrl + N` / `Ctrl + Q` are free for us to use.
- On macOS, while active, `Ctrl + N` overrides the Cocoa "move cursor down"
  binding inside text fields. Rebind to `Alt + N` (or `Ctrl + Shift + N` via the
  browser-level command) if that bothers you.
- On some Linux desktops `Ctrl + Q` is a window-manager "quit" accelerator that
  a web page cannot block. Rebind the peek key if you hit this.
- The panel does **not** appear on pages where Chrome forbids content scripts:
  `chrome://*`, the Chrome Web Store, the built-in PDF viewer, `view-source:`,
  and `file://` URLs (unless you enable file access for the extension). Use the
  toolbar popup on those pages.
- Keyboard shortcuts act on the **top frame** only; if keyboard focus is inside
  a cross-origin `<iframe>`, the shortcut won't fire until you click back out.
- When the two configured combos fire, the extension calls `preventDefault()` /
  `stopImmediatePropagation()` for those keys so the page and browser don't also
  react. Every other keystroke is passed through untouched.

---

## Privacy

- Notes live only in `chrome.storage.local` on this machine.
- No servers, no sync, no third-party requests, no analytics, no tracking.
- The extension never reads page content or browsing history. The only
  permission requested is `storage`.
- To wipe everything: remove the extension from `chrome://extensions`, or run
  `chrome.storage.local.clear()` from the extension's service-worker console.

---

## Project structure

```
quick-notes-extension/
  manifest.json                 Manifest V3; permission: ["storage"]
  icons/                        generated PNGs + master SVG
  tools/gen-icons.js            dependency-free PNG generator
  src/
    shared/
      constants.js              modes, storage keys, platform defaults, helpers
      date-utils.js             formatTimestamp() — "Today · 12:43 PM", local tz
      storage.js                the only module that touches chrome.storage.local
    content/
      styles.js                 all panel CSS as a string (injected into Shadow DOM)
      state.js                  the mode state machine + transitions + autosave
      panel.js                  Shadow-DOM panel: list / editor / peek / confirm
      keyboard.js               capture-phase key machine: hold, double-tap, Esc
      main.js                   bootstrap: wires storage ↔ state ↔ panel + keyboard
    background/
      service-worker.js         seeds settings; forwards the optional OS command
    popup/
      popup.html / .css / .js   full notes manager + settings
```

Separation of concerns: **UI** (`panel.js`, `popup/`), **keyboard**
(`keyboard.js`), **storage** (`storage.js`), **dates** (`date-utils.js`),
**lifecycle** (`main.js`, `service-worker.js`).

No build tooling. Content-script files are plain classic scripts that share one
namespace (`globalThis.QN`) inside the isolated world; the popup loads the same
shared files via `<script>` tags; the service worker via `importScripts`.

---

## Testing checklist

### New note
- [ ] `Mod + N` → panel opens, textarea focused, cursor active.
- [ ] Type → wait → refresh the page → note is still there.

### Persistence
- [ ] Create a note, refresh the tab, the note remains.
- [ ] Create a note in one tab; it appears in another tab's sticky panel and in
      the popup without a manual refresh.

### Editing
- [ ] Open a note (sticky click or popup), change it, close, reopen → change kept.
- [ ] Clear a brand-new note's text and close → it is not saved.

### Temporary view
- [ ] Hold `Mod + Q` → read-only list appears (no `+`, no `×`, rows not clickable).
- [ ] Release `Q` → panel disappears.
- [ ] Release `Ctrl`/`Alt` before `Q` → panel disappears.
- [ ] Release `Q` before the modifier → panel disappears.

### Sticky view
- [ ] `Mod + Q`, `Mod + Q` within 400 ms → panel stays after release.
- [ ] Click `×` → panel closes and sticky mode ends.
- [ ] Single `Mod + Q` while sticky → panel closes (default behaviour).

### Multiple notes
- [ ] Create 5+ notes: newest first, timestamps correct, list scrolls, long
      notes are truncated in the list and don't break the layout, panel stays compact.

### Keyboard edge cases
- [ ] Hold `Mod + Q` for several seconds → panel does not flicker or duplicate.
- [ ] Rapidly tap `Mod + Q` many times → no stray panels, ends in a predictable state.
- [ ] Switch tabs while holding `Mod + Q` → returning, no stuck panel.
- [ ] `Mod + N` while the editor is open → a new blank note.
- [ ] In a page text field, unrelated typing and the site's own shortcuts still work.

### Isolation
- [ ] On a CSS-heavy site the panel looks identical (Shadow DOM isolation).
- [ ] The panel does not shift or restyle the underlying page.
```
