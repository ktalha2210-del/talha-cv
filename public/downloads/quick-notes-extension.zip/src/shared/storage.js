/*
 * Quick Notes — persistence layer.
 *
 * The ONLY module that touches chrome.storage.local. Everything else goes
 * through QN.storage. No network, no sync, no analytics.
 *
 * Note shape:
 *   { id: string, content: string, createdAt: number, updatedAt: number }
 *
 * Notes are stored under one key as { notes: Note[] }.
 * Settings under another key as a partial of QN.DEFAULT_SETTINGS.
 */
(function () {
  "use strict";

  var root = typeof globalThis !== "undefined" ? globalThis : self;
  var QN = root.QN || (root.QN = {});

  if (QN.storage) return;

  var KEYS = QN.STORAGE_KEYS;
  var area = chrome.storage.local;

  /* Serialise writes within this context so overlapping debounced saves
   * don't read-modify-write over each other. */
  var writeQueue = Promise.resolve();
  function enqueue(fn) {
    var run = writeQueue.then(fn, fn);
    // Keep the chain alive even if a write rejects.
    writeQueue = run.catch(function () {});
    return run;
  }

  function get(key) {
    return area.get(key).then(function (res) {
      return res[key];
    });
  }
  function set(key, value) {
    var obj = {};
    obj[key] = value;
    return area.set(obj);
  }

  function readNotes() {
    return get(KEYS.NOTES).then(function (data) {
      if (data && Array.isArray(data.notes)) return data.notes.slice();
      return [];
    });
  }

  function sortDesc(notes) {
    return notes.slice().sort(function (a, b) {
      return (b.updatedAt || 0) - (a.updatedAt || 0);
    });
  }

  function sanitizeNote(n) {
    var now = Date.now();
    return {
      id: typeof n.id === "string" && n.id ? n.id : QN.uid(),
      content: typeof n.content === "string" ? n.content : "",
      createdAt: typeof n.createdAt === "number" ? n.createdAt : now,
      updatedAt: typeof n.updatedAt === "number" ? n.updatedAt : now
    };
  }

  var storage = {
    /* -------------------------------------------------- notes -------- */
    getNotes: function () {
      return readNotes().then(sortDesc);
    },

    getNote: function (id) {
      return readNotes().then(function (notes) {
        for (var i = 0; i < notes.length; i++) {
          if (notes[i].id === id) return notes[i];
        }
        return null;
      });
    },

    /**
     * Persist a note for the first time. Accepts a partial draft; missing
     * fields are filled. Returns the stored note.
     */
    createNote: function (draft) {
      draft = draft || {};
      return enqueue(function () {
        return readNotes().then(function (notes) {
          var note = sanitizeNote(draft);
          // Guard against a double-create for the same draft id.
          for (var i = 0; i < notes.length; i++) {
            if (notes[i].id === note.id) return notes[i];
          }
          notes.push(note);
          return set(KEYS.NOTES, { notes: notes }).then(function () {
            return note;
          });
        });
      });
    },

    /** Update content + updatedAt. Returns the updated note, or null. */
    updateNote: function (id, content) {
      return enqueue(function () {
        return readNotes().then(function (notes) {
          var updated = null;
          for (var i = 0; i < notes.length; i++) {
            if (notes[i].id === id) {
              notes[i] = {
                id: notes[i].id,
                content: typeof content === "string" ? content : "",
                createdAt: notes[i].createdAt,
                updatedAt: Date.now()
              };
              updated = notes[i];
              break;
            }
          }
          if (!updated) return null;
          return set(KEYS.NOTES, { notes: notes }).then(function () {
            return updated;
          });
        });
      });
    },

    /** Remove a note. Returns true if something was removed. */
    deleteNote: function (id) {
      return enqueue(function () {
        return readNotes().then(function (notes) {
          var next = notes.filter(function (n) {
            return n.id !== id;
          });
          if (next.length === notes.length) return false;
          return set(KEYS.NOTES, { notes: next }).then(function () {
            return true;
          });
        });
      });
    },

    /* ----------------------------------------------- settings ------- */
    getSettings: function () {
      return get(KEYS.SETTINGS).then(function (stored) {
        var out = {};
        var d = QN.DEFAULT_SETTINGS;
        for (var k in d) if (Object.prototype.hasOwnProperty.call(d, k)) out[k] = d[k];
        if (stored && typeof stored === "object") {
          for (var j in stored) {
            if (Object.prototype.hasOwnProperty.call(out, j)) out[j] = stored[j];
          }
        }
        // Normalise
        if (["Control", "Alt", "Meta"].indexOf(out.primaryModifier) === -1) {
          out.primaryModifier = QN.DEFAULT_SETTINGS.primaryModifier;
        }
        out.newNoteKey = QN.normalizeKey(out.newNoteKey, "n");
        out.peekKey = QN.normalizeKey(out.peekKey, "q");
        out.doubleTapWindow = QN.clamp(out.doubleTapWindow, 150, 1500);
        out.stickyCloseOnPeek = !!out.stickyCloseOnPeek;
        out.shortcutsEnabled = out.shortcutsEnabled !== false;
        return out;
      });
    },

    saveSettings: function (partial) {
      return enqueue(function () {
        return storage.getSettings().then(function (current) {
          var next = {};
          for (var k in current) {
            if (Object.prototype.hasOwnProperty.call(current, k)) next[k] = current[k];
          }
          if (partial && typeof partial === "object") {
            for (var j in partial) {
              if (Object.prototype.hasOwnProperty.call(next, j)) next[j] = partial[j];
            }
          }
          return set(KEYS.SETTINGS, next).then(function () {
            // Return the normalised view so callers never hold a raw value.
            return storage.getSettings();
          });
        });
      });
    },

    resetSettings: function () {
      return enqueue(function () {
        return set(KEYS.SETTINGS, {}).then(function () {
          return storage.getSettings();
        });
      });
    },

    /* Seed defaults on first install (service worker). No-op if present. */
    ensureSettings: function () {
      return get(KEYS.SETTINGS).then(function (stored) {
        if (stored && typeof stored === "object") return stored;
        return set(KEYS.SETTINGS, {}).then(function () {
          return {};
        });
      });
    },

    /* -------------------------------------------------- events ----- */
    /**
     * Subscribe to storage changes. cb receives { notes?: Note[], settings?: Settings }.
     * Returns an unsubscribe function.
     */
    onChange: function (cb) {
      function handler(changes, areaName) {
        if (areaName !== "local") return;
        var payload = {};
        var hit = false;
        if (changes[KEYS.NOTES]) {
          var nv = changes[KEYS.NOTES].newValue;
          payload.notes = sortDesc(
            nv && Array.isArray(nv.notes) ? nv.notes : []
          );
          hit = true;
        }
        if (changes[KEYS.SETTINGS]) {
          hit = true;
          payload.settingsChanged = true;
        }
        if (hit) {
          if (payload.settingsChanged) {
            storage.getSettings().then(function (s) {
              payload.settings = s;
              cb(payload);
            });
          } else {
            cb(payload);
          }
        }
      }
      chrome.storage.onChanged.addListener(handler);
      return function () {
        chrome.storage.onChanged.removeListener(handler);
      };
    }
  };

  QN.storage = storage;
})();
