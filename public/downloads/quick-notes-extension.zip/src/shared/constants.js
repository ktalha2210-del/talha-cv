/*
 * Quick Notes — shared constants & tiny helpers.
 *
 * Loaded as a classic script in three contexts (content script isolated world,
 * popup page, service worker). Everything is hung off a single namespace on the
 * global object so the no-build multi-file setup can share symbols.
 */
(function () {
  "use strict";

  var root = typeof globalThis !== "undefined" ? globalThis : self;
  var QN = root.QN || (root.QN = {});

  if (QN._constantsLoaded) return;
  QN._constantsLoaded = true;

  /* ---- Panel state machine ------------------------------------------------ */
  QN.MODES = {
    CLOSED: "closed",
    TEMPORARY: "temporary", // hold-to-peek, strictly read-only
    STICKY: "sticky", // pinned, interactive list
    EDITOR: "editor" // creating / editing a single note
  };

  /* ---- chrome.storage.local keys --------------------------------------- */
  QN.STORAGE_KEYS = {
    NOTES: "quickNotes:notes:v1",
    SETTINGS: "quickNotes:settings:v1"
  };

  /* ---- Platform detection --------------------------------------------- */
  // On macOS the browser/OS reserve Cmd (not Ctrl), so a content script can
  // safely observe Ctrl+N / Ctrl+Q. On Windows/Linux those are swallowed by
  // the browser, so we default the modifier to Alt there.
  QN.isMac = (function () {
    try {
      var p =
        (navigator.userAgentData && navigator.userAgentData.platform) ||
        navigator.platform ||
        navigator.userAgent ||
        "";
      return /mac|iphone|ipad|ipod/i.test(p);
    } catch (e) {
      return false;
    }
  })();

  /* ---- Default user settings ---------------------------------------- */
  QN.DEFAULT_SETTINGS = {
    // "Control" | "Alt" | "Meta"
    primaryModifier: QN.isMac ? "Control" : "Alt",
    newNoteKey: "n",
    peekKey: "q",
    doubleTapWindow: 400, // ms between peek presses to count as a double-tap
    stickyCloseOnPeek: true, // pressing the peek shortcut while sticky closes it
    shortcutsEnabled: true // master switch for all on-page shortcuts
  };

  QN.MODIFIER_LABELS = {
    Control: QN.isMac ? "Ctrl (⌃)" : "Ctrl",
    Alt: QN.isMac ? "Option (⌥)" : "Alt",
    Meta: QN.isMac ? "Cmd (⌘)" : "Win / Super"
  };

  /* ---- Misc -------------------------------------------------------- */
  QN.PREVIEW_MAX = 140; // chars shown in a list-row preview
  QN.SAVE_DEBOUNCE = 300; // ms debounce before writing to storage
  QN.HOST_ID = "quick-notes-host";
  QN.Z_INDEX = 2147483647;

  QN.uid = function () {
    try {
      if (root.crypto && typeof root.crypto.randomUUID === "function") {
        return root.crypto.randomUUID();
      }
    } catch (e) {
      /* fall through */
    }
    return (
      "n_" +
      Date.now().toString(36) +
      "_" +
      Math.random().toString(36).slice(2, 10)
    );
  };

  QN.clamp = function (n, min, max) {
    n = Number(n);
    if (isNaN(n)) return min;
    return Math.min(max, Math.max(min, n));
  };

  // Normalise a single-character key setting: lowercase, first char only.
  QN.normalizeKey = function (value, fallback) {
    if (typeof value !== "string") return fallback;
    var v = value.trim().toLowerCase();
    if (!v) return fallback;
    return v.slice(0, 1);
  };
})();
