/*
 * Quick Notes — date formatting.
 *
 * Produces short, human strings in the user's local timezone:
 *   Today · 12:43 PM
 *   Yesterday · 6:30 PM
 *   Sep 7 · 4:15 PM          (same calendar year)
 *   Sep 7, 2024 · 4:15 PM    (older year)
 *
 * Never hardcodes a timezone — Intl / Date use the host's local zone.
 */
(function () {
  "use strict";

  var root = typeof globalThis !== "undefined" ? globalThis : self;
  var QN = root.QN || (root.QN = {});

  if (QN._dateUtilsLoaded) return;
  QN._dateUtilsLoaded = true;

  function startOfDay(d) {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  }

  var timeFmt;
  var monthDayFmt;
  var monthDayYearFmt;

  function getTimeFmt() {
    if (!timeFmt) {
      timeFmt = new Intl.DateTimeFormat(undefined, {
        hour: "numeric",
        minute: "2-digit"
      });
    }
    return timeFmt;
  }
  function getMonthDayFmt() {
    if (!monthDayFmt) {
      monthDayFmt = new Intl.DateTimeFormat(undefined, {
        month: "short",
        day: "numeric"
      });
    }
    return monthDayFmt;
  }
  function getMonthDayYearFmt() {
    if (!monthDayYearFmt) {
      monthDayYearFmt = new Intl.DateTimeFormat(undefined, {
        month: "short",
        day: "numeric",
        year: "numeric"
      });
    }
    return monthDayYearFmt;
  }

  /**
   * @param {number} ts epoch milliseconds
   * @param {number} [nowTs] epoch milliseconds (injectable for tests)
   * @returns {string}
   */
  QN.formatTimestamp = function (ts, nowTs) {
    if (!ts && ts !== 0) return "";
    var date = new Date(ts);
    if (isNaN(date.getTime())) return "";

    var now = new Date(nowTs || Date.now());
    var today = startOfDay(now);
    var target = startOfDay(date);
    var dayDiff = Math.round((today - target) / 86400000);

    var time = getTimeFmt().format(date);

    var datePart;
    if (dayDiff === 0) {
      datePart = "Today";
    } else if (dayDiff === 1) {
      datePart = "Yesterday";
    } else if (date.getFullYear() === now.getFullYear()) {
      datePart = getMonthDayFmt().format(date);
    } else {
      datePart = getMonthDayYearFmt().format(date);
    }

    return datePart + " · " + time;
  };
})();
