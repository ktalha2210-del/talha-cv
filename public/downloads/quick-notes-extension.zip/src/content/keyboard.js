/*
 * Quick Notes — keyboard state machine.
 *
 * Listens in the capture phase so it can act before the page, but ONLY ever
 * calls preventDefault / stopImmediatePropagation for the two exact configured
 * combos (and Escape while our editor is open). Every other key is left alone.
 *
 *   Mod + N            → new note (EDITOR)
 *   Mod + Q  (hold)    → TEMPORARY read-only peek; closes on release
 *   Mod + Q  (x2 fast) → STICKY (stays open)
 *   Mod + Q  (sticky)  → close        [configurable: stickyCloseOnPeek]
 *   Escape (editor)    → back / close (never deletes)
 */
(function () {
  "use strict";

  var root = typeof globalThis !== "undefined" ? globalThis : self;
  var QN = root.QN || (root.QN = {});
  var M = QN.MODES;

  if (QN.keyboard) return;

  function settings() {
    return QN.state.settings || QN.DEFAULT_SETTINGS;
  }

  function now() {
    return typeof performance !== "undefined" && performance.now
      ? performance.now()
      : Date.now();
  }

  function modifierMatches(e) {
    switch (settings().primaryModifier) {
      case "Control":
        return e.ctrlKey && !e.altKey && !e.metaKey && !e.shiftKey;
      case "Alt":
        return e.altKey && !e.ctrlKey && !e.metaKey && !e.shiftKey;
      case "Meta":
        return e.metaKey && !e.ctrlKey && !e.altKey && !e.shiftKey;
      default:
        return false;
    }
  }

  function keyMatches(e, key) {
    if (!key) return false;
    if (e.key && e.key.toLowerCase() === key) return true;
    if (e.code && e.code.toLowerCase() === "key" + key) return true;
    return false;
  }

  /* ------------------------------------------------ peek logic ---- */

  function handlePeekDown() {
    var keys = QN.state.keys;
    var st = settings();
    var t = now();

    if (QN.state.mode === M.STICKY) {
      if (st.stickyCloseOnPeek) QN.actions.close();
      keys.lastPeekDownAt = t;
      return;
    }
    if (QN.state.mode === M.EDITOR) {
      keys.lastPeekDownAt = t;
      return; // don't disturb an open editor
    }

    keys.peekDown = true;
    // Only a *previous* real press counts toward a double-tap — guard against
    // t being small right after page load (performance.now() starts near 0).
    var isDouble =
      keys.lastPeekDownAt > 0 && t - keys.lastPeekDownAt <= st.doubleTapWindow;
    if (isDouble) {
      QN.actions.openSticky();
    } else {
      QN.actions.openTemporary();
    }
    keys.lastPeekDownAt = t;
  }

  /* ------------------------------------------------ handlers ----- */

  function onKeyDown(e) {
    var st = settings();

    // Escape leaves the editor. Handled regardless of the shortcuts toggle,
    // but only when our editor is actually open.
    if (e.key === "Escape" && QN.state.mode === M.EDITOR) {
      e.stopPropagation();
      QN.actions.backFromEditor();
      return;
    }

    if (!st.shortcutsEnabled) return;

    if (modifierMatches(e)) QN.state.keys.modifierDown = true;

    if (modifierMatches(e) && keyMatches(e, st.newNoteKey)) {
      e.preventDefault();
      e.stopImmediatePropagation();
      if (e.repeat) return;
      QN.actions.newNote();
      return;
    }

    if (modifierMatches(e) && keyMatches(e, st.peekKey)) {
      e.preventDefault();
      e.stopImmediatePropagation();
      if (e.repeat) return;
      handlePeekDown();
      return;
    }
  }

  function onKeyUp(e) {
    var keys = QN.state.keys;
    var st = settings();

    if (
      (e.key === "Control" || e.key === "Alt" || e.key === "Meta") &&
      e.key === st.primaryModifier
    ) {
      keys.modifierDown = false;
    }
    if (keyMatches(e, st.peekKey)) {
      keys.peekDown = false;
    }

    if (
      QN.state.mode === M.TEMPORARY &&
      (!keys.peekDown || !keys.modifierDown)
    ) {
      QN.actions.close();
    }
  }

  function resetKeys() {
    var keys = QN.state.keys;
    keys.modifierDown = false;
    keys.peekDown = false;
    if (QN.state.mode === M.TEMPORARY) QN.actions.close();
  }

  function onVisibility() {
    if (document.hidden) resetKeys();
  }

  /* ------------------------------------------------ lifecycle --- */

  var attached = false;

  function attach() {
    if (attached) return;
    attached = true;
    window.addEventListener("keydown", onKeyDown, true);
    window.addEventListener("keyup", onKeyUp, true);
    window.addEventListener("blur", resetKeys);
    document.addEventListener("visibilitychange", onVisibility);
  }

  function detach() {
    if (!attached) return;
    attached = false;
    window.removeEventListener("keydown", onKeyDown, true);
    window.removeEventListener("keyup", onKeyUp, true);
    window.removeEventListener("blur", resetKeys);
    document.removeEventListener("visibilitychange", onVisibility);
  }

  QN.keyboard = { attach: attach, detach: detach };
})();
