/*
 * Quick Notes — central state + transitions.
 *
 * One `mode` variable drives everything (no scattered booleans that could form
 * impossible states). Transitions are the only way to change mode; each one
 * ends by asking the panel to re-render.
 *
 *   CLOSED ──Mod+Q hold──▶ TEMPORARY ──release──▶ CLOSED
 *   CLOSED ──Mod+Q x2────▶ STICKY ──× / peek────▶ CLOSED
 *   any ────Mod+N────────▶ EDITOR ──Esc / back──▶ (STICKY | CLOSED)
 */
(function () {
  "use strict";

  var root = typeof globalThis !== "undefined" ? globalThis : self;
  var QN = root.QN || (root.QN = {});
  var M = QN.MODES;

  if (QN.state) return;

  QN.state = {
    mode: M.CLOSED,
    activeNoteId: null, // note (or draft) currently in the editor
    editorReturnTo: M.CLOSED, // where Esc / back goes from the editor
    draftPersisted: false, // has the current editor note been written yet?
    sessionCreated: false, // was it created in this editor session (via +/Mod+N)?
    pendingContent: "", // latest textarea value awaiting a debounced save
    hasPendingSave: false,
    notes: [], // cached, sorted updatedAt DESC
    settings: QN.DEFAULT_SETTINGS,
    _focusEditor: false, // panel should grab focus on next render
    keys: { modifierDown: false, peekDown: false, lastPeekDownAt: 0 }
  };

  var S = QN.state;
  var saveTimer = null;

  function render() {
    if (QN.panel && typeof QN.panel.render === "function") QN.panel.render();
  }
  QN.render = render;

  function isVisible() {
    return S.mode !== M.CLOSED;
  }
  QN.isVisible = isVisible;

  function currentNote() {
    if (!S.activeNoteId) return null;
    for (var i = 0; i < S.notes.length; i++) {
      if (S.notes[i].id === S.activeNoteId) return S.notes[i];
    }
    return null;
  }
  QN.currentNote = currentNote;

  /* -------------------------------------------------- saving --------- */

  function clearTimer() {
    if (saveTimer) {
      clearTimeout(saveTimer);
      saveTimer = null;
    }
  }

  function scheduleSave() {
    clearTimer();
    saveTimer = setTimeout(function () {
      saveTimer = null;
      flush();
    }, QN.SAVE_DEBOUNCE);
  }

  /**
   * Write the editor's pending content immediately. Returns a Promise.
   * Rules:
   *  - A brand-new note is only persisted once it has non-blank content.
   *  - A note created this session that ends up blank is removed on close.
   *  - An existing note is never auto-deleted, only updated.
   */
  function status(tone) {
    if (QN.panel && typeof QN.panel.setStatus === "function") {
      QN.panel.setStatus(tone);
    }
  }
  function markSaved() {
    status("saved");
  }

  function flush() {
    clearTimer();
    if (!S.hasPendingSave) return Promise.resolve();

    var id = S.activeNoteId;
    var content = S.pendingContent;
    var blank = content.trim() === "";
    S.hasPendingSave = false;

    if (!id) return Promise.resolve();

    if (!S.draftPersisted) {
      if (blank) return Promise.resolve(); // never write an empty new note
      var note = currentNote() || {
        id: id,
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
      S.draftPersisted = true;
      return QN.storage
        .createNote({
          id: id,
          content: content,
          createdAt: note.createdAt,
          updatedAt: Date.now()
        })
        .then(markSaved, noop);
    }

    if (blank && S.sessionCreated) {
      S.draftPersisted = false;
      return QN.storage.deleteNote(id).then(noop, noop);
    }

    return QN.storage.updateNote(id, content).then(markSaved, noop);
  }
  QN.flush = flush;

  function noop() {}

  /* ---------------------------------------------- editor input ------ */

  function handleInput(value) {
    if (S.mode !== M.EDITOR) return;
    S.pendingContent = value;
    S.hasPendingSave = true;

    // Optimistic cache update so a re-render (e.g. from another surface)
    // doesn't flash stale text.
    var note = currentNote();
    if (note) {
      note.content = value;
      note.updatedAt = Date.now();
    } else {
      S.notes.unshift({
        id: S.activeNoteId,
        content: value,
        createdAt: Date.now(),
        updatedAt: Date.now()
      });
    }
    if (QN.panel && typeof QN.panel.setStatus === "function") {
      QN.panel.setStatus(value.trim() === "" ? "idle" : "saving");
    }
    scheduleSave();
  }
  QN.handleInput = handleInput;

  /* ------------------------------------------------ transitions ----- */

  function endEditorSession() {
    // Called when leaving the editor. Persist, then drop an untouched draft.
    var pending = flush();
    if (!S.draftPersisted && S.activeNoteId) {
      // Draft was never written — remove any optimistic cache entry.
      S.notes = S.notes.filter(function (n) {
        return n.id !== S.activeNoteId;
      });
    }
    S.activeNoteId = null;
    S.draftPersisted = false;
    S.sessionCreated = false;
    S.pendingContent = "";
    S.hasPendingSave = false;
    return pending;
  }

  var actions = {
    setNotes: function (notes) {
      S.notes = Array.isArray(notes) ? notes : [];
      if (isVisible() && S.mode !== M.EDITOR) render();
    },

    setSettings: function (settings) {
      S.settings = settings || QN.DEFAULT_SETTINGS;
    },

    /* hold-to-peek */
    openTemporary: function () {
      if (S.mode !== M.CLOSED) return;
      S.mode = M.TEMPORARY;
      render();
    },

    /* double-tap */
    openSticky: function () {
      if (S.mode === M.STICKY || S.mode === M.EDITOR) return;
      S.mode = M.STICKY;
      render();
    },

    /* Mod+N, or the + button */
    newNote: function (returnTo) {
      if (typeof returnTo === "undefined") {
        returnTo = S.mode === M.STICKY || S.mode === M.EDITOR ? M.STICKY : M.CLOSED;
      }
      // Reuse an untouched blank draft instead of stacking.
      if (
        S.mode === M.EDITOR &&
        !S.draftPersisted &&
        S.pendingContent.trim() === ""
      ) {
        S._focusEditor = true;
        render();
        return;
      }
      if (S.mode === M.EDITOR) endEditorSession();

      var now = Date.now();
      var draft = { id: QN.uid(), content: "", createdAt: now, updatedAt: now };
      S.activeNoteId = draft.id;
      S.draftPersisted = false;
      S.sessionCreated = true;
      S.pendingContent = "";
      S.hasPendingSave = false;
      S.editorReturnTo = returnTo;
      S.mode = M.EDITOR;
      S._focusEditor = true;
      render();
    },

    /* click an existing note (sticky mode only) */
    editNote: function (id, returnTo) {
      var target = null;
      for (var i = 0; i < S.notes.length; i++) {
        if (S.notes[i].id === id) target = S.notes[i];
      }
      if (!target) return;
      if (S.mode === M.EDITOR) endEditorSession();

      S.activeNoteId = id;
      S.draftPersisted = true;
      S.sessionCreated = false;
      S.pendingContent = target.content || "";
      S.hasPendingSave = false;
      S.editorReturnTo = returnTo || M.STICKY;
      S.mode = M.EDITOR;
      S._focusEditor = true;
      render();
    },

    /* delete a note straight from the list (with row confirmation) */
    deleteNoteById: function (id) {
      if (!id) return;
      S.notes = S.notes.filter(function (n) {
        return n.id !== id;
      });
      render();
      QN.storage.deleteNote(id).then(noop, noop);
    },

    /* delete the note in the editor */
    deleteActive: function () {
      var id = S.activeNoteId;
      clearTimer();
      S.hasPendingSave = false;
      var returnTo = S.editorReturnTo;
      S.notes = S.notes.filter(function (n) {
        return n.id !== id;
      });
      S.activeNoteId = null;
      S.draftPersisted = false;
      S.sessionCreated = false;
      S.pendingContent = "";
      S.mode = returnTo === M.STICKY ? M.STICKY : M.CLOSED;
      render();
      if (id) QN.storage.deleteNote(id).then(noop, noop);
    },

    /* editor "back" / Escape */
    backFromEditor: function () {
      var returnTo = S.editorReturnTo;
      endEditorSession();
      S.mode = returnTo === M.STICKY ? M.STICKY : M.CLOSED;
      render();
    },

    /* editor: Enter → commit + confirm + exit */
    saveAndExitEditor: function () {
      var note = currentNote();
      var text = (note ? note.content : S.pendingContent) || "";
      var wroteSomething = text.trim() !== "" && (S.hasPendingSave || S.draftPersisted);

      var returnTo = S.editorReturnTo;
      endEditorSession();
      S.mode = returnTo === M.STICKY ? M.STICKY : M.CLOSED;
      render();
      if (wroteSomething && QN.panel && typeof QN.panel.toast === "function") {
        QN.panel.toast("Saved");
      }
    },

    /* close everything (× button, release of a temporary peek, cleanup) */
    close: function () {
      if (S.mode === M.EDITOR) endEditorSession();
      S.mode = M.CLOSED;
      render();
    }
  };

  QN.actions = actions;
})();
