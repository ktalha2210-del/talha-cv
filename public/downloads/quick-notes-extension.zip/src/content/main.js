/*
 * Quick Notes — content-script bootstrap.
 *
 * Wires storage → state → panel, attaches the keyboard machine, listens for the
 * optional service-worker "create-note" command, and keeps the panel alive if a
 * page rips it out of the DOM.
 */
(function () {
  "use strict";

  var root = typeof globalThis !== "undefined" ? globalThis : self;
  var QN = root.QN || (root.QN = {});
  var M = QN.MODES;

  if (QN._contentBooted) return;
  QN._contentBooted = true;

  /* ---- initial load ------------------------------------------------ */
  QN.storage.getSettings().then(function (settings) {
    QN.actions.setSettings(settings);
    QN.keyboard.attach();
  });

  QN.storage.getNotes().then(function (notes) {
    QN.actions.setNotes(notes);
  });

  /* ---- live sync across tabs / popup ----------------------------- */
  QN.storage.onChange(function (payload) {
    if (payload.settings) {
      QN.actions.setSettings(payload.settings);
      if (QN.isVisible() && QN.state.mode !== M.EDITOR) QN.render();
    }

    if (payload.notes) {
      if (QN.state.mode === M.EDITOR) {
        // Don't disturb the editor. Refresh the cache but protect the note
        // the user is actively typing into.
        var activeId = QN.state.activeNoteId;
        var merged = payload.notes.slice();
        if (QN.state.hasPendingSave && activeId) {
          var found = false;
          for (var i = 0; i < merged.length; i++) {
            if (merged[i].id === activeId) {
              merged[i] = {
                id: activeId,
                content: QN.state.pendingContent,
                createdAt: merged[i].createdAt,
                updatedAt: Date.now()
              };
              found = true;
              break;
            }
          }
          if (!found) {
            merged.unshift({
              id: activeId,
              content: QN.state.pendingContent,
              createdAt: Date.now(),
              updatedAt: Date.now()
            });
          }
        }
        QN.state.notes = merged;
      } else {
        QN.actions.setNotes(payload.notes);
      }
    }
  });

  /* ---- optional OS-level command from the service worker -------- */
  try {
    chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
      if (msg && msg.type === "create-note") {
        QN.actions.newNote();
        if (sendResponse) sendResponse({ ok: true });
      }
      return false;
    });
  } catch (e) {
    /* runtime may be unavailable in some contexts */
  }

  /* ---- persist on the way out --------------------------------- */
  function flushOut() {
    try {
      QN.flush();
    } catch (e) {
      /* noop */
    }
  }
  window.addEventListener("pagehide", flushOut);
  window.addEventListener("beforeunload", flushOut);

  /* ---- survive hostile DOM resets (no polling) --------------- */
  try {
    var mo = new MutationObserver(function () {
      if (
        QN.state.mode !== M.CLOSED &&
        QN.panel &&
        !QN.panel.isMounted()
      ) {
        QN.render();
      }
    });
    mo.observe(document.documentElement, { childList: true });
  } catch (e) {
    /* documentElement not ready — panel.render re-appends anyway */
  }
})();
