/*
 * Quick Notes — the in-page panel.
 *
 * A single Shadow DOM host (created lazily, removed when CLOSED), centred on the
 * viewport and rendered from QN.state. All interaction is delegated from one
 * listener per event type so innerHTML can be rebuilt freely.
 *
 * Extras: a dim backdrop while editing, a live "Saving…/Saved" status in the
 * editor footer, and a "Saved" toast when a note is committed with Enter.
 */
(function () {
  "use strict";

  var root = typeof globalThis !== "undefined" ? globalThis : self;
  var QN = root.QN || (root.QN = {});
  var M = QN.MODES;

  if (QN.panel) return;

  var host = null;
  var shadow = null;
  var container = null;
  var backdrop = null;
  var toastEl = null;
  var removeTimer = null;
  var statusRevertTimer = null;
  var toastHideTimer = null;
  var toastCleanupTimer = null;
  var toastActive = false;
  var confirmingDelete = false;
  var pendingRowDeleteId = null; // list row awaiting delete confirmation

  var LOGO_SVG =
    '<svg class="qn-logo" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
    '<rect x="1" y="1" width="30" height="30" rx="8" fill="#3b6fe0"/>' +
    '<path d="M8.5 24V8H12l8 10V8h3.5v16H20l-8-10v10z" fill="#fff"/></svg>';

  var TRASH_SVG =
    '<svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
    '<path fill="currentColor" d="M6.5 1.5h3l.6 1H13v1.6H3V2.5h2.9l.6-1ZM3.8 5h8.4l-.7 8.4a1.2 1.2 0 0 1-1.2 1.1H5.7a1.2 1.2 0 0 1-1.2-1.1L3.8 5Zm2.4 1.8v5.4h1V6.8h-1Zm2.6 0v5.4h1V6.8h-1Z"/></svg>';

  /* ------------------------------------------------ helpers -------- */

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function modLabel() {
    var s = (QN.state.settings || QN.DEFAULT_SETTINGS).primaryModifier;
    if (s === "Control") return QN.isMac ? "⌃" : "Ctrl";
    if (s === "Alt") return QN.isMac ? "⌥" : "Alt";
    if (s === "Meta") return QN.isMac ? "⌘" : "Win";
    return "Ctrl";
  }

  function newNoteHint() {
    var key = (QN.state.settings || QN.DEFAULT_SETTINGS).newNoteKey || "n";
    return modLabel() + " + " + key.toUpperCase();
  }

  function preview(content) {
    var text = (content || "").trim();
    if (!text) {
      return '<p class="qn-item__preview qn-empty-note">Empty note</p>';
    }
    if (text.length > QN.PREVIEW_MAX) text = text.slice(0, QN.PREVIEW_MAX) + "…";
    return '<p class="qn-item__preview">' + esc(text) + "</p>";
  }

  /* -------------------------------------------------- markup ------- */

  function headerHTML(mode) {
    var title = '<span class="qn-title">' + LOGO_SVG + "Notes</span>";
    if (mode === M.TEMPORARY) {
      return '<header class="qn-header">' + title + "</header>";
    }
    if (mode === M.STICKY) {
      return (
        '<header class="qn-header">' +
        title +
        '<span class="qn-actions">' +
        '<button class="qn-btn qn-btn--primary" type="button" data-act="new" aria-label="New note" title="New note">+</button>' +
        '<button class="qn-btn" type="button" data-act="close" aria-label="Close notes" title="Close">×</button>' +
        "</span></header>"
      );
    }
    // EDITOR
    var back =
      QN.state.editorReturnTo === M.STICKY
        ? '<button class="qn-btn qn-btn--back" type="button" data-act="back" aria-label="Back to notes" title="Back">←</button>'
        : "";
    return (
      '<header class="qn-header">' +
      back +
      title +
      '<span class="qn-actions">' +
      '<button class="qn-btn" type="button" data-act="close" aria-label="Close notes" title="Close">×</button>' +
      "</span></header>"
    );
  }

  function emptyHTML() {
    return (
      '<div class="qn-empty">' +
      '<div class="qn-empty__mark" aria-hidden="true">✎</div>' +
      '<p class="qn-empty__title">No notes yet</p>' +
      '<p class="qn-empty__hint">Press <kbd>' +
      esc(newNoteHint()) +
      "</kbd> to create one.</p>" +
      "</div>"
    );
  }

  function listHTML(mode) {
    var notes = QN.state.notes || [];
    if (!notes.length) return emptyHTML();

    var readonly = mode === M.TEMPORARY;
    var rows = notes
      .map(function (n, i) {
        var delay = i > 12 ? 12 : i;

        if (!readonly && n.id === pendingRowDeleteId) {
          return (
            '<li class="qn-item qn-item--confirm" style="--i:' +
            delay +
            '">' +
            '<span class="qn-rowconfirm__text">Delete this note?</span>' +
            '<span class="qn-rowconfirm__actions">' +
            '<button type="button" data-act="cancel-row-del">Cancel</button>' +
            '<button type="button" class="qn-confirm__danger" data-act="confirm-row-del" data-id="' +
            esc(n.id) +
            '">Delete</button>' +
            "</span></li>"
          );
        }

        var attrs = readonly
          ? 'class="qn-item" style="--i:' + delay + '"'
          : 'class="qn-item" style="--i:' +
            delay +
            '" role="button" tabindex="0" data-act="edit" data-id="' +
            esc(n.id) +
            '"';
        var delBtn = readonly
          ? ""
          : '<button type="button" class="qn-item__del" data-act="row-del" data-id="' +
            esc(n.id) +
            '" aria-label="Delete note" title="Delete">' +
            TRASH_SVG +
            "</button>";
        return (
          "<li " +
          attrs +
          ">" +
          delBtn +
          preview(n.content) +
          '<p class="qn-item__meta">' +
          esc(QN.formatTimestamp(n.updatedAt)) +
          "</p></li>"
        );
      })
      .join("");

    return (
      '<ul class="qn-list' +
      (readonly ? " qn-list--readonly" : "") +
      '">' +
      rows +
      "</ul>"
    );
  }

  function editorHTML() {
    var note = QN.currentNote();
    var content = note ? note.content || "" : QN.state.pendingContent || "";

    var bottom;
    if (confirmingDelete) {
      bottom =
        '<div class="qn-confirm" role="alertdialog" aria-label="Confirm delete">' +
        '<span class="qn-confirm__text">Delete this note?</span>' +
        '<button type="button" data-act="cancel-delete">Cancel</button>' +
        '<button type="button" class="qn-confirm__danger" data-act="confirm-delete">Delete</button>' +
        "</div>";
    } else {
      bottom =
        '<div class="qn-footer">' +
        '<span class="qn-hint">' +
        "<kbd>↵</kbd> Save <span aria-hidden=\"true\">·</span> <kbd>⇧ ↵</kbd> New line" +
        "</span>" +
        '<span class="qn-status" data-tone="" role="status" hidden></span>' +
        '<button type="button" class="qn-delete" data-act="ask-delete" aria-label="Delete note">Delete</button>' +
        "</div>";
    }

    return (
      '<div class="qn-editor">' +
      '<textarea class="qn-editor__area" spellcheck="true" ' +
      'placeholder="Type your note…  (Enter saves, Shift+Enter for a new line)" aria-label="Note text">' +
      esc(content) +
      "</textarea>" +
      bottom +
      "</div>"
    );
  }

  function bodyHTML(mode) {
    if (mode === M.EDITOR) return editorHTML();
    return '<div class="qn-body">' + listHTML(mode) + "</div>";
  }

  function buildHTML() {
    var mode = QN.state.mode;
    var role = mode === M.EDITOR ? "dialog" : "region";
    return (
      '<div class="qn-panel" role="' +
      role +
      '" aria-label="Quick Notes">' +
      headerHTML(mode) +
      bodyHTML(mode) +
      "</div>"
    );
  }

  /* -------------------------------------------------- events ------ */

  function actionEl(e) {
    var path = e.composedPath ? e.composedPath() : [e.target];
    for (var i = 0; i < path.length; i++) {
      if (path[i] === container) break;
      if (path[i] && path[i].getAttribute && path[i].getAttribute("data-act")) {
        return path[i];
      }
    }
    return null;
  }

  function onClick(e) {
    var el = actionEl(e);
    if (!el) return;
    var act = el.getAttribute("data-act");

    if (act === "new") QN.actions.newNote(M.STICKY);
    else if (act === "close") QN.actions.close();
    else if (act === "back") QN.actions.backFromEditor();
    else if (act === "edit") QN.actions.editNote(el.getAttribute("data-id"), M.STICKY);
    else if (act === "row-del") {
      pendingRowDeleteId = el.getAttribute("data-id");
      render();
    } else if (act === "cancel-row-del") {
      pendingRowDeleteId = null;
      render();
    } else if (act === "confirm-row-del") {
      var rid = el.getAttribute("data-id");
      pendingRowDeleteId = null;
      QN.actions.deleteNoteById(rid);
    } else if (act === "ask-delete") {
      confirmingDelete = true;
      render();
    } else if (act === "cancel-delete") {
      confirmingDelete = false;
      QN.state._focusEditor = true;
      render();
    } else if (act === "confirm-delete") {
      confirmingDelete = false;
      QN.actions.deleteActive();
    }
  }

  function onKeydown(e) {
    var t = e.target;

    // Editor: Enter commits, Shift+Enter inserts a newline (default).
    if (t && t.classList && t.classList.contains("qn-editor__area")) {
      if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
        e.preventDefault();
        QN.actions.saveAndExitEditor();
      }
      return;
    }

    // List rows: Enter / Space opens the note.
    if (
      (e.key === "Enter" || e.key === " ") &&
      t &&
      t.getAttribute &&
      t.getAttribute("data-act") === "edit"
    ) {
      e.preventDefault();
      QN.actions.editNote(t.getAttribute("data-id"), M.STICKY);
    }
  }

  function onInput(e) {
    var t = e.target;
    if (t && t.classList && t.classList.contains("qn-editor__area")) {
      QN.handleInput(t.value);
    }
  }

  function onFocusOut(e) {
    var t = e.target;
    if (t && t.classList && t.classList.contains("qn-editor__area")) {
      QN.flush();
    }
  }

  /* -------------------------------------------------- host -------- */

  function ensureHost() {
    if (host && host.isConnected) return;
    if (!host) {
      host = document.createElement("div");
      host.id = QN.HOST_ID;
      host.style.cssText =
        "all:initial; position:fixed; inset:0 auto auto 0; width:0; height:0; z-index:" +
        QN.Z_INDEX +
        ";";
      shadow = host.attachShadow ? host.attachShadow({ mode: "open" }) : host;

      var style = document.createElement("style");
      style.textContent = QN.PANEL_CSS;
      shadow.appendChild(style);

      backdrop = document.createElement("div");
      backdrop.className = "qn-backdrop";
      backdrop.addEventListener("click", function () {
        QN.actions.backFromEditor();
      });
      shadow.appendChild(backdrop);

      container = document.createElement("div");
      container.className = "qn-container";
      shadow.appendChild(container);

      container.addEventListener("click", onClick);
      container.addEventListener("keydown", onKeydown);
      container.addEventListener("input", onInput);
      container.addEventListener("focusout", onFocusOut);
    }
    var mount = document.documentElement || document.body;
    if (mount) mount.appendChild(host);
  }

  function hide() {
    if (!host) return;
    var panelEl = shadow && shadow.querySelector(".qn-panel");
    if (panelEl) panelEl.classList.remove("qn-visible");
    if (backdrop) backdrop.classList.remove("qn-backdrop--show");
    if (removeTimer) clearTimeout(removeTimer);
    removeTimer = setTimeout(function () {
      removeTimer = null;
      if (QN.state.mode === M.CLOSED && host && !toastActive) {
        host.remove();
        host = shadow = container = backdrop = toastEl = null;
      }
    }, 160);
  }

  /* live save status (no re-render → caret stays put) */
  function setStatus(tone) {
    if (!shadow) return;
    var hint = shadow.querySelector(".qn-hint");
    var st = shadow.querySelector(".qn-status");
    if (!st || !hint) return;
    if (statusRevertTimer) {
      clearTimeout(statusRevertTimer);
      statusRevertTimer = null;
    }
    if (tone === "saving") {
      st.setAttribute("data-tone", "saving");
      st.textContent = "Saving…";
      st.hidden = false;
      hint.hidden = true;
    } else if (tone === "saved") {
      st.setAttribute("data-tone", "saved");
      st.textContent = "✓ Saved";
      st.hidden = false;
      hint.hidden = true;
      statusRevertTimer = setTimeout(function () {
        setStatus("idle");
      }, 1500);
    } else {
      st.hidden = true;
      st.setAttribute("data-tone", "");
      hint.hidden = false;
    }
  }

  /* transient "Saved" pill, survives view changes / panel close */
  function toast(text) {
    ensureHost();
    if (removeTimer) {
      clearTimeout(removeTimer);
      removeTimer = null;
    }
    toastActive = true;
    if (!toastEl) {
      toastEl = document.createElement("div");
      toastEl.className = "qn-toast";
      toastEl.setAttribute("role", "status");
      shadow.appendChild(toastEl);
    }
    toastEl.innerHTML =
      '<span class="qn-toast__check" aria-hidden="true">✓</span><span class="qn-toast__label"></span>';
    toastEl.querySelector(".qn-toast__label").textContent = text || "Saved";
    void toastEl.offsetWidth; // reflow so the transition plays
    toastEl.classList.add("qn-toast--show");

    if (toastHideTimer) clearTimeout(toastHideTimer);
    if (toastCleanupTimer) clearTimeout(toastCleanupTimer);
    toastHideTimer = setTimeout(function () {
      if (toastEl) toastEl.classList.remove("qn-toast--show");
      toastCleanupTimer = setTimeout(function () {
        toastActive = false;
        if (QN.state.mode === M.CLOSED) hide();
      }, 280);
    }, 1400);
  }

  function render() {
    var S = QN.state;

    if (S.mode === M.CLOSED) {
      confirmingDelete = false;
      pendingRowDeleteId = null;
      hide();
      return;
    }
    if (S.mode !== M.EDITOR) confirmingDelete = false;
    if (S.mode !== M.STICKY) pendingRowDeleteId = null;

    ensureHost();
    if (removeTimer) {
      clearTimeout(removeTimer);
      removeTimer = null;
    }

    container.innerHTML = buildHTML();

    if (backdrop) {
      backdrop.classList.toggle("qn-backdrop--show", S.mode === M.EDITOR);
    }

    var panelEl = shadow.querySelector(".qn-panel");
    if (panelEl) {
      requestAnimationFrame(function () {
        if (panelEl) panelEl.classList.add("qn-visible");
      });
    }

    if (S.mode === M.EDITOR && S._focusEditor) {
      var ta = shadow.querySelector(".qn-editor__area");
      if (ta) {
        ta.focus();
        var len = ta.value.length;
        try {
          ta.setSelectionRange(len, len);
        } catch (err) {
          /* some browsers throw on hidden elements */
        }
      }
      S._focusEditor = false;
    }
  }

  QN.panel = {
    render: render,
    setStatus: setStatus,
    toast: toast,
    isMounted: function () {
      return !!(host && host.isConnected);
    },
    destroy: function () {
      if (host) host.remove();
      host = shadow = container = backdrop = toastEl = null;
    }
  };
})();
