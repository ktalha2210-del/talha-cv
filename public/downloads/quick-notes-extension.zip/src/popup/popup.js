/*
 * Quick Notes — toolbar popup.
 *
 * A full notes manager (browse / edit / delete / new) plus a minimal settings
 * pane. Shares QN.storage / QN.formatTimestamp with the content script via the
 * plain <script> tags in popup.html.
 */
(function () {
  "use strict";

  var QN = window.QN;

  var VIEW = { LIST: "list", EDITOR: "editor", SETTINGS: "settings" };

  var state = {
    view: VIEW.LIST,
    activeId: null,
    notes: [],
    settings: QN.DEFAULT_SETTINGS,
    draftPersisted: false,
    sessionCreated: false,
    pending: "",
    hasPending: false,
    confirmingDelete: false,
    rowDeleteId: null // list row awaiting delete confirmation
  };

  var TRASH_SVG =
    '<svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
    '<path fill="currentColor" d="M6.5 1.5h3l.6 1H13v1.6H3V2.5h2.9l.6-1ZM3.8 5h8.4l-.7 8.4a1.2 1.2 0 0 1-1.2 1.1H5.7a1.2 1.2 0 0 1-1.2-1.1L3.8 5Zm2.4 1.8v5.4h1V6.8h-1Zm2.6 0v5.4h1V6.8h-1Z"/></svg>';

  var els = {
    back: document.getElementById("btn-back"),
    title: document.getElementById("hdr-title"),
    "new": document.getElementById("btn-new"),
    settings: document.getElementById("btn-settings"),
    view: document.getElementById("view")
  };

  var saveTimer = null;

  /* ---------------------------------------------------- utils ----- */

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function modLabel(mod) {
    mod = mod || state.settings.primaryModifier;
    if (mod === "Control") return QN.isMac ? "⌃" : "Ctrl";
    if (mod === "Alt") return QN.isMac ? "⌥" : "Alt";
    if (mod === "Meta") return QN.isMac ? "⌘" : "Win";
    return "Ctrl";
  }

  function currentNote() {
    for (var i = 0; i < state.notes.length; i++) {
      if (state.notes[i].id === state.activeId) return state.notes[i];
    }
    return null;
  }

  /* --------------------------------------------------- saving ---- */

  function clearTimer() {
    if (saveTimer) {
      clearTimeout(saveTimer);
      saveTimer = null;
    }
  }

  function scheduleSave() {
    clearTimer();
    saveTimer = setTimeout(function () {
      saveTimer = null;
      flush();
    }, QN.SAVE_DEBOUNCE);
  }

  function flush() {
    clearTimer();
    if (!state.hasPending) return Promise.resolve();
    var id = state.activeId;
    var content = state.pending;
    var blank = content.trim() === "";
    state.hasPending = false;
    if (!id) return Promise.resolve();

    if (!state.draftPersisted) {
      if (blank) return Promise.resolve();
      state.draftPersisted = true;
      var n = currentNote();
      return QN.storage
        .createNote({
          id: id,
          content: content,
          createdAt: n ? n.createdAt : Date.now(),
          updatedAt: Date.now()
        })
        .then(afterSave);
    }
    if (blank && state.sessionCreated) {
      state.draftPersisted = false;
      return QN.storage.deleteNote(id);
    }
    return QN.storage.updateNote(id, content).then(afterSave);
  }

  function afterSave(v) {
    setStatus("saved");
    return v;
  }

  /* ------------------------------------------------ navigation --- */

  function saveAndClose() {
    var note = currentNote();
    var text = (note ? note.content : state.pending) || "";
    var wrote = text.trim() !== "" && (state.hasPending || state.draftPersisted);
    toList();
    if (wrote) toast("Saved");
  }

  function toList() {
    flush();
    if (!state.draftPersisted && state.activeId) {
      state.notes = state.notes.filter(function (nn) {
        return nn.id !== state.activeId;
      });
    }
    state.view = VIEW.LIST;
    state.activeId = null;
    state.draftPersisted = false;
    state.sessionCreated = false;
    state.pending = "";
    state.hasPending = false;
    state.confirmingDelete = false;
    render();
  }

  function openExisting(id) {
    flush();
    var note = null;
    for (var i = 0; i < state.notes.length; i++) {
      if (state.notes[i].id === id) note = state.notes[i];
    }
    if (!note) return;
    state.view = VIEW.EDITOR;
    state.activeId = id;
    state.draftPersisted = true;
    state.sessionCreated = false;
    state.pending = note.content || "";
    state.hasPending = false;
    state.confirmingDelete = false;
    render();
  }

  function openNew() {
    flush();
    if (!state.draftPersisted && state.activeId) {
      state.notes = state.notes.filter(function (nn) {
        return nn.id !== state.activeId;
      });
    }
    var now = Date.now();
    state.view = VIEW.EDITOR;
    state.activeId = QN.uid();
    state.draftPersisted = false;
    state.sessionCreated = true;
    state.pending = "";
    state.hasPending = false;
    state.confirmingDelete = false;
    render();
  }

  function openSettings() {
    flush();
    state.view = VIEW.SETTINGS;
    state.confirmingDelete = false;
    render();
  }

  function deleteActive() {
    var id = state.activeId;
    clearTimer();
    state.hasPending = false;
    state.notes = state.notes.filter(function (nn) {
      return nn.id !== id;
    });
    state.activeId = null;
    state.draftPersisted = false;
    state.sessionCreated = false;
    state.pending = "";
    state.view = VIEW.LIST;
    state.confirmingDelete = false;
    render();
    if (id) QN.storage.deleteNote(id);
  }

  function onInput(value) {
    state.pending = value;
    state.hasPending = true;
    var note = currentNote();
    if (note) {
      note.content = value;
      note.updatedAt = Date.now();
    } else {
      state.notes.unshift({
        id: state.activeId,
        content: value,
        createdAt: Date.now(),
        updatedAt: Date.now()
      });
    }
    setStatus(value.trim() === "" ? "idle" : "saving");
    scheduleSave();
  }

  /* ------------------------------------------------ feedback ---- */

  var statusTimer = null;
  function setStatus(tone) {
    var hint = els.view.querySelector(".editor__hint");
    var st = els.view.querySelector(".editor__status");
    if (!hint || !st) return;
    if (statusTimer) {
      clearTimeout(statusTimer);
      statusTimer = null;
    }
    if (tone === "saving") {
      st.textContent = "Saving…";
      st.setAttribute("data-tone", "saving");
      st.hidden = false;
      hint.hidden = true;
    } else if (tone === "saved") {
      st.textContent = "✓ Saved";
      st.setAttribute("data-tone", "saved");
      st.hidden = false;
      hint.hidden = true;
      statusTimer = setTimeout(function () {
        setStatus("idle");
      }, 1500);
    } else {
      st.hidden = true;
      st.setAttribute("data-tone", "");
      hint.hidden = false;
    }
  }

  var toastEl = null;
  var toastTimer = null;
  function toast(text) {
    if (!toastEl) {
      toastEl = document.createElement("div");
      toastEl.className = "toast";
      toastEl.setAttribute("role", "status");
      document.body.appendChild(toastEl);
    }
    toastEl.innerHTML =
      '<span class="toast__check" aria-hidden="true">✓</span><span class="toast__label"></span>';
    toastEl.querySelector(".toast__label").textContent = text || "Saved";
    void toastEl.offsetWidth;
    toastEl.classList.add("is-show");
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      if (toastEl) toastEl.classList.remove("is-show");
    }, 1300);
  }

  /* -------------------------------------------------- rendering -- */

  function renderHeader() {
    if (state.view === VIEW.LIST) {
      els.title.textContent = "Notes";
      els.back.hidden = true;
      els["new"].hidden = false;
      els.settings.hidden = false;
    } else if (state.view === VIEW.EDITOR) {
      els.title.textContent = "Notes";
      els.back.hidden = false;
      els["new"].hidden = true;
      els.settings.hidden = true;
    } else {
      els.title.textContent = "Settings";
      els.back.hidden = false;
      els["new"].hidden = true;
      els.settings.hidden = true;
    }
  }

  function previewHTML(content) {
    var text = (content || "").trim();
    if (!text) return '<p class="item__preview is-empty">Empty note</p>';
    if (text.length > QN.PREVIEW_MAX) text = text.slice(0, QN.PREVIEW_MAX) + "…";
    return '<p class="item__preview">' + esc(text) + "</p>";
  }

  function renderList() {
    var hint = modLabel() + " + " + (state.settings.newNoteKey || "n").toUpperCase();
    var html =
      '<div class="new-row">' +
      '<button class="new-btn" type="button" id="pp-new">+ New note</button>' +
      "</div>";

    if (!state.notes.length) {
      html +=
        '<div class="empty">' +
        '<div class="empty__mark" aria-hidden="true">✎</div>' +
        '<p class="empty__title">No notes yet</p>' +
        '<p class="empty__hint">Press <kbd>' +
        esc(hint) +
        "</kbd> on any page, or the button above.</p>" +
        "</div>";
      els.view.innerHTML = html;
      wireList();
      return;
    }

    html += '<ul class="list">';
    html += state.notes
      .map(function (n, i) {
        var d = i > 12 ? 12 : i;
        if (n.id === state.rowDeleteId) {
          return (
            '<li class="item item--confirm" style="--i:' +
            d +
            '">' +
            '<span class="rowconfirm__text">Delete this note?</span>' +
            '<span class="rowconfirm__actions">' +
            '<button type="button" data-pp="row-cancel">Cancel</button>' +
            '<button type="button" class="danger" data-pp="row-confirm" data-id="' +
            esc(n.id) +
            '">Delete</button>' +
            "</span></li>"
          );
        }
        return (
          '<li class="item" role="button" tabindex="0" style="--i:' +
          d +
          '" data-id="' +
          esc(n.id) +
          '">' +
          '<button type="button" class="item__del" data-pp="row-del" data-id="' +
          esc(n.id) +
          '" aria-label="Delete note" title="Delete">' +
          TRASH_SVG +
          "</button>" +
          previewHTML(n.content) +
          '<p class="item__meta">' +
          esc(QN.formatTimestamp(n.updatedAt)) +
          "</p></li>"
        );
      })
      .join("");
    html += "</ul>";
    els.view.innerHTML = html;
    wireList();
  }

  function wireList() {
    var nb = document.getElementById("pp-new");
    if (nb) nb.addEventListener("click", openNew);

    Array.prototype.forEach.call(
      els.view.querySelectorAll("[data-pp]"),
      function (btn) {
        btn.addEventListener("click", function (e) {
          e.stopPropagation();
          var pp = btn.getAttribute("data-pp");
          if (pp === "row-del") {
            state.rowDeleteId = btn.getAttribute("data-id");
            render();
          } else if (pp === "row-cancel") {
            state.rowDeleteId = null;
            render();
          } else if (pp === "row-confirm") {
            var id = btn.getAttribute("data-id");
            state.rowDeleteId = null;
            state.notes = state.notes.filter(function (nn) {
              return nn.id !== id;
            });
            render();
            QN.storage.deleteNote(id);
          }
        });
      }
    );

    Array.prototype.forEach.call(
      els.view.querySelectorAll(".item[data-id]"),
      function (li) {
        li.addEventListener("click", function () {
          openExisting(li.getAttribute("data-id"));
        });
        li.addEventListener("keydown", function (e) {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            openExisting(li.getAttribute("data-id"));
          }
        });
      }
    );
  }

  function renderEditor() {
    var note = currentNote();
    var content = note ? note.content || "" : state.pending || "";

    var bottom;
    if (state.confirmingDelete) {
      bottom =
        '<div class="confirm" role="alertdialog" aria-label="Confirm delete">' +
        '<span class="confirm__text">Delete this note?</span>' +
        '<button type="button" id="pp-cancel-del">Cancel</button>' +
        '<button type="button" class="danger" id="pp-confirm-del">Delete</button>' +
        "</div>";
    } else {
      bottom =
        '<div class="editor__foot">' +
        '<span class="editor__hint"><kbd>↵</kbd> Save <span aria-hidden="true">·</span> <kbd>⇧ ↵</kbd> New line</span>' +
        '<span class="editor__status" data-tone="" role="status" hidden></span>' +
        '<button type="button" class="link-btn" id="pp-del" aria-label="Delete note">Delete</button>' +
        "</div>";
    }

    els.view.innerHTML =
      '<div class="editor">' +
      '<textarea class="editor__area" spellcheck="true" placeholder="Type your note…  (Enter saves, Shift+Enter for a new line)" aria-label="Note text">' +
      esc(content) +
      "</textarea>" +
      bottom +
      "</div>";

    var ta = els.view.querySelector(".editor__area");
    ta.addEventListener("input", function () {
      onInput(ta.value);
    });
    ta.addEventListener("blur", flush);
    ta.addEventListener("keydown", function (e) {
      if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
        e.preventDefault();
        saveAndClose();
      }
    });
    ta.focus();
    try {
      ta.setSelectionRange(ta.value.length, ta.value.length);
    } catch (e) {}

    var del = document.getElementById("pp-del");
    if (del)
      del.addEventListener("click", function () {
        state.confirmingDelete = true;
        render();
      });
    var cancel = document.getElementById("pp-cancel-del");
    if (cancel)
      cancel.addEventListener("click", function () {
        state.confirmingDelete = false;
        render();
      });
    var confirm = document.getElementById("pp-confirm-del");
    if (confirm) confirm.addEventListener("click", deleteActive);
  }

  function renderSettings() {
    var s = state.settings;
    var m = modLabel();
    var summary =
      "New note <strong>" +
      esc(m + " + " + (s.newNoteKey || "n").toUpperCase()) +
      "</strong> · Peek <strong>Hold " +
      esc(m + " + " + (s.peekKey || "q").toUpperCase()) +
      "</strong> · Sticky <strong>" +
      esc(m + " + " + (s.peekKey || "q").toUpperCase() + " ×2") +
      "</strong>";

    function opt(v) {
      return (
        '<option value="' +
        v +
        '"' +
        (s.primaryModifier === v ? " selected" : "") +
        ">" +
        esc(QN.MODIFIER_LABELS[v]) +
        "</option>"
      );
    }

    els.view.innerHTML =
      '<div class="settings">' +
      '<p class="settings__summary">' +
      summary +
      "</p>" +
      '<div class="field"><span class="field__label">Modifier key' +
      "<small>Alt is the default on Windows/Linux — Ctrl+N/Ctrl+Q can't be intercepted there.</small>" +
      '</span><select id="set-mod">' +
      opt("Control") +
      opt("Alt") +
      opt("Meta") +
      "</select></div>" +
      '<div class="field"><span class="field__label">New note key</span>' +
      '<input type="text" id="set-newkey" maxlength="1" value="' +
      esc(s.newNoteKey || "n") +
      '" /></div>' +
      '<div class="field"><span class="field__label">Peek key</span>' +
      '<input type="text" id="set-peekkey" maxlength="1" value="' +
      esc(s.peekKey || "q") +
      '" /></div>' +
      '<div class="field"><span class="field__label">Double-tap window' +
      "<small>Max gap between two peek presses for sticky mode.</small></span>" +
      '<input type="number" id="set-window" min="150" max="1500" step="50" value="' +
      esc(s.doubleTapWindow) +
      '" /> <span class="field__label" style="flex:0 0 auto">ms</span></div>' +
      '<div class="field"><span class="field__label">Peek key closes sticky panel' +
      "<small>When on, pressing the peek shortcut while sticky closes it.</small></span>" +
      '<input type="checkbox" id="set-sticky"' +
      (s.stickyCloseOnPeek ? " checked" : "") +
      " /></div>" +
      '<div class="field"><span class="field__label">On-page shortcuts' +
      "<small>Master switch for the in-page keyboard behaviour.</small></span>" +
      '<input type="checkbox" id="set-enabled"' +
      (s.shortcutsEnabled ? " checked" : "") +
      " /></div>" +
      '<p class="settings__note">Tip: bind a browser-level “Create a new note” key at ' +
      "<strong>chrome://extensions/shortcuts</strong> as a fallback.</p>" +
      '<div class="settings__actions">' +
      '<button class="btn" type="button" id="set-reset">Reset to platform defaults</button>' +
      "</div>" +
      "</div>";

    document.getElementById("set-mod").addEventListener("change", function (e) {
      save({ primaryModifier: e.target.value });
    });
    document
      .getElementById("set-newkey")
      .addEventListener("change", function (e) {
        save({ newNoteKey: QN.normalizeKey(e.target.value, "n") });
      });
    document
      .getElementById("set-peekkey")
      .addEventListener("change", function (e) {
        save({ peekKey: QN.normalizeKey(e.target.value, "q") });
      });
    document.getElementById("set-window").addEventListener("change", function (e) {
      save({ doubleTapWindow: QN.clamp(e.target.value, 150, 1500) });
    });
    document.getElementById("set-sticky").addEventListener("change", function (e) {
      save({ stickyCloseOnPeek: e.target.checked });
    });
    document
      .getElementById("set-enabled")
      .addEventListener("change", function (e) {
        save({ shortcutsEnabled: e.target.checked });
      });
    document.getElementById("set-reset").addEventListener("click", function () {
      QN.storage.resetSettings().then(function (s2) {
        state.settings = s2;
        render();
      });
    });
  }

  function save(partial) {
    QN.storage.saveSettings(partial).then(function (s) {
      state.settings = s;
    });
  }

  function render() {
    if (state.view !== VIEW.LIST) state.rowDeleteId = null;
    renderHeader();
    if (state.view === VIEW.LIST) renderList();
    else if (state.view === VIEW.EDITOR) renderEditor();
    else renderSettings();
  }

  /* ------------------------------------------------- listeners --- */

  els.back.addEventListener("click", toList);
  els["new"].addEventListener("click", openNew);
  els.settings.addEventListener("click", openSettings);
  window.addEventListener("pagehide", flush);
  window.addEventListener("blur", flush);

  QN.storage.onChange(function (payload) {
    if (payload.settings) {
      state.settings = payload.settings;
      if (state.view !== VIEW.EDITOR) render();
    }
    if (payload.notes) {
      if (state.view === VIEW.EDITOR) {
        var merged = payload.notes.slice();
        if (state.hasPending && state.activeId) {
          var found = false;
          for (var i = 0; i < merged.length; i++) {
            if (merged[i].id === state.activeId) {
              merged[i] = {
                id: state.activeId,
                content: state.pending,
                createdAt: merged[i].createdAt,
                updatedAt: Date.now()
              };
              found = true;
            }
          }
          if (!found) {
            merged.unshift({
              id: state.activeId,
              content: state.pending,
              createdAt: Date.now(),
              updatedAt: Date.now()
            });
          }
        }
        state.notes = merged;
      } else {
        state.notes = payload.notes;
        render();
      }
    }
  });

  /* ---------------------------------------------------- boot ---- */

  Promise.all([QN.storage.getSettings(), QN.storage.getNotes()]).then(function (
    res
  ) {
    state.settings = res[0];
    state.notes = res[1];
    render();
  });
})();
