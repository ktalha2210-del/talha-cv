/*
 * Quick Notes — service worker (Manifest V3).
 *
 * Deliberately tiny. Two jobs:
 *   1. Seed default settings on install.
 *   2. Forward the optional OS-level "create-note" command (bound by the user
 *      at chrome://extensions/shortcuts) to the active tab's content script.
 *
 * No tabs/host permissions needed: chrome.tabs.query returns the active tab id
 * without them, and tabs.sendMessage only needs the target tab id.
 */

importScripts(
  chrome.runtime.getURL("src/shared/constants.js"),
  chrome.runtime.getURL("src/shared/storage.js")
);

var QN = self.QN;

chrome.runtime.onInstalled.addListener(function () {
  QN.storage.ensureSettings().catch(function () {});
});

chrome.commands.onCommand.addListener(function (command) {
  if (command !== "create-note") return;
  chrome.tabs
    .query({ active: true, currentWindow: true })
    .then(function (tabs) {
      var tab = tabs && tabs[0];
      if (!tab || tab.id == null) return;
      return chrome.tabs.sendMessage(tab.id, { type: "create-note" });
    })
    .catch(function () {
      // The page has no content script (chrome://, Web Store, PDF viewer, …).
      // Nothing we can do there; the popup is the fallback surface.
    });
});
