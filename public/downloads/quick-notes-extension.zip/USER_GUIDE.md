# Quick Notes — User Guide

A pocket scratchpad that sits on top of any web page. No tabs, no accounts, no
Save button. Everything stays on your computer.

Throughout this guide, **`Mod`** means:

| Your OS | `Mod` key |
|---|---|
| macOS | **Ctrl** |
| Windows / Linux | **Alt** |

(You can change this and every other key in **Settings** — see the bottom.)

---

## The three gestures

### ✍️  Write a note — `Mod + N`

Press it anywhere. The panel opens in the **middle of the screen** with the
cursor already blinking — just start typing.

- **Enter** — save and close. A green **✓ Saved** appears, then a **Saved** pill.
- **Shift + Enter** — start a new line.
- The footer also shows **Saving… → ✓ Saved** live while you type, so you always
  know it's stored.
- **Esc** or **×** — leave the editor. A brand-new note with no text is thrown
  away, not saved.

### 👀  Peek at your notes — hold `Mod + Q`

Hold the keys down to see your notes. Let go and they vanish. It's a glance —
read-only, nothing to click, your place on the page is untouched.

### 📌  Keep notes open — `Mod + Q`, `Mod + Q`

Tap it twice quickly (within about half a second) and the panel **stays open**
after you release the keys. Now you can:

- scroll through everything,
- click any note to edit it,
- click **+** to start a new one,
- click **×** to close (or just tap `Mod + Q` once more).

---

## Everyday tasks

| I want to… | Do this |
|---|---|
| Jot something down fast | `Mod + N`, type, `Enter` |
| Re-read a note without losing my spot | Hold `Mod + Q`, read, release |
| Fix a typo in an old note | `Mod + Q` twice → click the note → edit → `Enter` |
| Delete a note | Hover the row → click 🗑 → confirm **Delete** (works in the panel and the popup) |
| See all notes in one place | Click the **N** icon in the toolbar |
| Change the shortcut keys | Toolbar **N** icon → gear icon |

Notes are always listed **newest first**, with a timestamp like
`Today · 2:14 PM` or `Sep 3 · 9:40 AM`.

---

## The toolbar popup

Click the **N** icon in Chrome's toolbar for the full view:

- **Notes** — browse, open, edit, or delete any note; **+ New note** to add one.
- **Settings** (gear icon) — see below.

Use the popup on pages where the on-page panel can't appear (see *Good to know*).

---

## Settings

Open the popup → gear icon.

| Setting | What it does |
|---|---|
| **Modifier key** | The `Mod` key: Ctrl, Alt, or Cmd/Win. |
| **New note key** | The letter for "new note" (default `n`). |
| **Peek key** | The letter for peek / sticky (default `q`). |
| **Double-tap window** | How close together the two taps must be for sticky mode. |
| **Peek key closes sticky panel** | On: tapping the peek shortcut while pinned closes it. Off: only **×** closes it. |
| **On-page shortcuts** | Master switch. Turn off to disable all page shortcuts and use only the popup. |
| **Reset to platform defaults** | Puts everything back. |

There's also an optional browser-level shortcut. Go to
`chrome://extensions/shortcuts`, find **Quick Notes → "Create a new note"**, and
assign a key. It works even on pages where the normal shortcut can't.

---

## Good to know

- **Your notes never leave your machine.** No sync, no servers, no tracking. To
  erase everything, remove the extension from `chrome://extensions`.
- **The panel can't open on a few pages:** Chrome's own pages (`chrome://…`), the
  Chrome Web Store, the built-in PDF viewer, and local `file://` pages. Use the
  toolbar popup there.
- **Windows / Linux use `Alt`, not `Ctrl`,** because the browser keeps `Ctrl + N`
  and `Ctrl + Q` for itself. On macOS `Ctrl` is free, so that's the default there.
- **On macOS,** while Quick Notes is active, `Ctrl + N` won't do its usual
  "move cursor down" inside text fields. Switch the new-note key to `Alt + N` in
  Settings if you'd rather keep that.
- **A held peek always cleans up.** Switch tabs or apps mid-peek and the panel
  won't get stuck open.
- Typing in the editor: your normal keys work as expected. Shortcuts only fire
  for the exact `Mod +` combinations you've configured.
